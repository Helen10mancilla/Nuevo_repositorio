@extends('layouts.plantilla')

@section('contenido')
    
   <h3> todo el contenido de producto agregar</h3>
@endsection

