@extends('layouts.plantilla')

@section('contenido')
    
   <h3> todo el contenido de producto index</h3>
@endsection